// API взаимодействие с backend
class CountdownAPI {
    constructor() {
        this.baseURL = window.location.origin;
    }

    // Получение настроек
    async getSettings() {
        try {
            const response = await fetch(`${this.baseURL}/api/settings`);
            return await response.json();
        } catch (error) {
            console.error('Ошибка загрузки настроек:', error);
            return null;
        }
    }

    // Обновление настроек
    async updateSettings(newSettings) {
        try {
            const response = await fetch(`${this.baseURL}/api/settings`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newSettings)
            });
            return await response.json();
        } catch (error) {
            console.error('Ошибка обновления настроек:', error);
            return { success: false };
        }
    }

    // Получение контента страницы "Об авторе"
    async getAboutContent() {
        try {
            const response = await fetch(`${this.baseURL}/api/content/about`);
            const data = await response.json();
            return data.content;
        } catch (error) {
            console.error('Ошибка загрузки контента:', error);
            return null;
        }
    }

    // Получение списка аудиофайлов
    async getAudioPlaylist() {
        try {
            const response = await fetch(`${this.baseURL}/api/media/audio`);
            return await response.json();
        } catch (error) {
            console.error('Ошибка загрузки плейлиста:', error);
            return [];
        }
    }

    // Отправка статистики
    async trackPageView(page, userId = null) {
        try {
            await fetch(`${this.baseURL}/api/statistics/pageview`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ page, userId })
            });
        } catch (error) {
            console.error('Ошибка отправки статистики:', error);
        }
    }

    // Генерация ID пользователя
    getUserId() {
        let userId = localStorage.getItem('userId');
        if (!userId) {
            userId = 'user_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('userId', userId);
        }
        return userId;
    }
}

// Создаем глобальный экземпляр API
const countdownAPI = new CountdownAPI();