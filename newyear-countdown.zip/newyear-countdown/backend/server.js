const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Логирование всех запросов
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// ==================== НАСТРОЙКА MULTER ДЛЯ ЗАГРУЗКИ ФАЙЛОВ ====================

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        let uploadPath = '';
        
        if (file.fieldname === 'audio') {
            uploadPath = '../frontend/media/audio/';
        } else if (file.fieldname === 'image') {
            uploadPath = '../frontend/media/images/';
        } else if (file.fieldname === 'video') {
            uploadPath = '../frontend/media/video/';
        } else {
            uploadPath = '../frontend/media/other/';
        }
        
        const fullPath = path.join(__dirname, uploadPath);
        
        if (!fs.existsSync(fullPath)) {
            fs.mkdirSync(fullPath, { recursive: true });
            console.log(`✅ Создана папка: ${fullPath}`);
        }
        
        cb(null, fullPath);
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ 
    storage: storage,
    fileFilter: function (req, file, cb) {
        console.log(`📁 Проверка файла: ${file.originalname}, тип: ${file.mimetype}, поле: ${file.fieldname}`);
        
        if (file.fieldname === 'audio') {
            if (!file.originalname.toLowerCase().endsWith('.mp3')) {
                return cb(new Error('Только MP3 файлы разрешены для аудио'), false);
            }
        } else if (file.fieldname === 'image') {
            if (!file.mimetype.startsWith('image/') || 
                !['image/jpeg', 'image/png', 'image/gif'].includes(file.mimetype)) {
                return cb(new Error('Только JPEG, PNG и GIF изображения разрешены'), false);
            }
        } else if (file.fieldname === 'video') {
            if (!file.mimetype.startsWith('video/')) {
                return cb(new Error('Только видео файлы разрешены'), false);
            }
        }
        
        cb(null, true);
    }
    // limits УДАЛЕН
});

// ==================== СОЗДАНИЕ ПАПОК ====================

const folders = ['audio', 'images', 'video'];
folders.forEach(folder => {
    const dirPath = path.join(__dirname, `../frontend/media/${folder}`);
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        console.log(`✅ Создана папка: ${dirPath}`);
    }
});

// ==================== ДАННЫЕ ====================

let settings = {
    switchTime: '23:55',
    fontSize: '120pt',
    timerLeft: '1530',
    timerTop: '790',
    backgroundBefore: 'background.jpg',
    backgroundAfter: 'after-congratulation-bg.jpg',
    backgroundVideo: 'background-video.mp4' // Новое поле для видео фона
};

let statistics = {
    pageViews: { main: 0, timer: 0, about: 0 },
    uniqueUsers: new Set()
};

// ==================== API РОУТЫ ====================

app.get('/api/settings', (req, res) => {
    console.log('GET /api/settings');
    res.json(settings);
});

app.post('/api/settings', (req, res) => {
    console.log('POST /api/settings', req.body);
    Object.assign(settings, req.body);
    res.json({ success: true, message: 'Настройки сохранены' });
});

app.get('/api/media/audio', (req, res) => {
    console.log('GET /api/media/audio');
    const audioDir = path.join(__dirname, '../frontend/media/audio');
    
    fs.readdir(audioDir, (err, files) => {
        if (err) {
            console.error('Ошибка чтения папки audio:', err);
            return res.json([]);
        }
        const mp3Files = files.filter(file => file.toLowerCase().endsWith('.mp3'));
        console.log('Найдено файлов:', mp3Files.length);
        res.json(mp3Files.sort());
    });
});

// ==================== ЗАГРУЗКА ФАЙЛОВ ====================

app.post('/api/upload/audio', upload.single('audio'), (req, res) => {
    console.log('POST /api/upload/audio');
    
    if (!req.file) {
        console.error('❌ Файл не был загружен');
        return res.status(400).json({ 
            success: false, 
            message: 'Файл не был загружен или произошла ошибка' 
        });
    }
    
    console.log(`✅ Файл загружен: ${req.file.originalname}`);
    console.log(`📁 Сохранен в: ${req.file.path}`);
    console.log(`📏 Размер: ${(req.file.size / 1024 / 1024).toFixed(2)} MB`);
    
    res.json({ 
        success: true, 
        message: 'Аудиофайл успешно загружен',
        filename: req.file.filename,
        size: req.file.size
    });
});

app.post('/api/upload/image', upload.single('image'), (req, res) => {
    console.log('POST /api/upload/image');
    
    if (!req.file) {
        console.error('❌ Изображение не было загружено');
        return res.status(400).json({ 
            success: false, 
            message: 'Изображение не было загружено' 
        });
    }
    
    console.log(`✅ Изображение загружено: ${req.file.originalname}`);
    console.log(`📁 Сохранен в: ${req.file.path}`);
    
    const fileExtension = path.extname(req.file.originalname).toLowerCase();
    let newFilename;
    
    if (req.body.type === 'backgroundBefore') {
        newFilename = 'background' + fileExtension;
    } else {
        newFilename = 'after-congratulation-bg' + fileExtension;
    }
    
    const newPath = path.join(path.dirname(req.file.path), newFilename);
    fs.renameSync(req.file.path, newPath);
    console.log(`🔄 Переименован в: ${newFilename}`);
    
    res.json({ 
        success: true, 
        message: 'Изображение успешно загружено',
        filename: newFilename
    });
});

app.post('/api/upload/video', upload.single('video'), (req, res) => {
    console.log('POST /api/upload/video');
    
    if (!req.file) {
        console.error('❌ Видео не было загружено');
        return res.status(400).json({ 
            success: false, 
            message: 'Видео не было загружено' 
        });
    }
    
    console.log(`✅ Видео загружено: ${req.file.originalname}`);
    console.log(`📁 Сохранен в: ${req.file.path}`);
    
    let newFilename;
    
    // Определяем имя файла в зависимости от типа
    if (req.body.type === 'backgroundVideo') {
        newFilename = 'background-video.mp4';
    } else if (req.body.type === 'congratulationVideo') {
        newFilename = 'congratulation.mp4';
    } else {
        // Если тип не указан, используем оригинальное имя
        newFilename = req.file.originalname;
    }
    
    const newPath = path.join(path.dirname(req.file.path), newFilename);
    
    try {
        // Проверяем, существует ли файл с таким именем
        if (fs.existsSync(newPath)) {
            console.log(`🔄 Файл ${newFilename} уже существует, заменяем...`);
            fs.unlinkSync(newPath);
        }
        
        fs.renameSync(req.file.path, newPath);
        console.log(`🔄 Переименован в: ${newFilename}`);
        
        // Если это фон, обновляем настройки
        if (req.body.type === 'backgroundVideo') {
            settings.backgroundVideo = newFilename;
        }
        
        res.json({ 
            success: true, 
            message: 'Видео успешно загружено',
            filename: newFilename
        });
    } catch (error) {
        console.error('❌ Ошибка при сохранении видео:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Ошибка при сохранении видео на сервере' 
        });
    }
});

app.delete('/api/media/audio/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, '../frontend/media/audio', filename);
    
    console.log(`DELETE /api/media/audio/${filename}`);
    
    fs.unlink(filePath, (err) => {
        if (err) {
            console.error('❌ Ошибка удаления файла:', err);
            return res.status(500).json({ 
                success: false, 
                message: 'Ошибка удаления файла' 
            });
        }
        
        console.log(`✅ Файл удален: ${filename}`);
        res.json({ 
            success: true, 
            message: 'Файл успешно удален' 
        });
    });
});

// ==================== ДРУГИЕ API ====================

app.post('/api/statistics/pageview', (req, res) => {
    const { page, userId } = req.body;
    
    if (statistics.pageViews[page] !== undefined) {
        statistics.pageViews[page]++;
    }
    
    if (userId) {
        statistics.uniqueUsers.add(userId);
    }
    
    res.json({ success: true });
});

app.get('/api/statistics', (req, res) => {
    res.json({
        pageViews: statistics.pageViews,
        uniqueUsers: statistics.uniqueUsers.size,
        onlineUsers: 0
    });
});

app.get('/api/playlist/random', (req, res) => {
    const audioDir = path.join(__dirname, '../frontend/media/audio');
    
    fs.readdir(audioDir, (err, files) => {
        if (err) return res.json([]);
        
        const mp3Files = files.filter(file => file.toLowerCase().endsWith('.mp3'));
        const shuffled = [...mp3Files].sort(() => Math.random() - 0.5);
        res.json(shuffled);
    });
});

app.post('/api/server/restart', (req, res) => {
    console.log('🔄 Запрос на перезагрузку сервера');
    res.json({ 
        success: true, 
        message: 'Сервер будет перезагружен через 3 секунды' 
    });
    
    setTimeout(() => {
        console.log('🔄 Перезагрузка сервера...');
        process.exit(0);
    }, 3000);
});

// ==================== ОБРАБОТКА ОШИБОК ====================

app.use((error, req, res, next) => {
    if (error instanceof multer.MulterError) {
        console.error('❌ Ошибка Multer:', error);
        return res.status(400).json({
            success: false,
            message: `Ошибка загрузки файла: ${error.message}`
        });
    } else if (error) {
        console.error('❌ Ошибка загрузки:', error);
        return res.status(400).json({
            success: false,
            message: error.message
        });
    }
    next();
});

// ==================== ЗАПУСК СЕРВЕРА ====================

app.listen(PORT, '0.0.0.0', () => {
    console.log('========================================');
    console.log('🎄 Сервер New Year Countdown ЗАПУЩЕН!');
    console.log('========================================');
    console.log(`📍 Порт: ${PORT}`);
    console.log('✅ Доступные страницы:');
    console.log(`   📱 Главная: http://localhost:${PORT}`);
    console.log(`   ⏰ Таймер: http://localhost:${PORT}/timer.html`);
    console.log(`   👤 Об авторе: http://localhost:${PORT}/about.html`);
    console.log(`   🔧 Админка: http://localhost:${PORT}/admin.html`);
    console.log('========================================');
});