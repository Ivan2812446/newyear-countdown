let joystickActive = false;
let currentX = 1104;
let currentY = 564;

// Пароль для доступа
const ADMIN_PASSWORD = 'passwd';

// Элементы DOM
const loginScreen = document.getElementById('login-screen');
const adminPanel = document.getElementById('admin-panel');
const passwordInput = document.getElementById('password-input');
const errorMessage = document.getElementById('error-message');

// Проверка пароля
function checkPassword() {
    const enteredPassword = passwordInput.value.trim();
    
    if (enteredPassword === ADMIN_PASSWORD) {
        loginScreen.classList.add('hidden');
        adminPanel.classList.remove('hidden');
        loadAdminData();
    } else {
        errorMessage.textContent = '❌ Неверный пароль';
        errorMessage.style.display = 'block';
        passwordInput.value = '';
        passwordInput.focus();
    }
}

// Выход из админ-панели
function logout() {
    adminPanel.classList.add('hidden');
    loginScreen.classList.remove('hidden');
    passwordInput.value = '';
    errorMessage.style.display = 'none';
}

// Загрузка данных при входе
async function loadAdminData() {
    await loadStatistics();
    await loadSettings();
    await loadAudioList();
}

// ==================== СТАТИСТИКА ====================

async function loadStatistics() {
    try {
        const response = await fetch('/api/statistics');
        const stats = await response.json();
        
        document.getElementById('stat-main').textContent = stats.pageViews.main;
        document.getElementById('stat-timer').textContent = stats.pageViews.timer;
        document.getElementById('stat-about').textContent = stats.pageViews.about;
        document.getElementById('stat-unique').textContent = stats.uniqueUsers;
        
    } catch (error) {
        console.error('Ошибка загрузки статистики:', error);
        showMessage('❌ Ошибка загрузки статистики', 'error');
    }
}

// ==================== НАСТРОЙКИ ====================

async function loadSettings() {
    try {
        const response = await fetch('/api/settings');
        const settings = await response.json();
        
        document.getElementById('setting-switchTime').value = settings.switchTime;
        document.getElementById('setting-fontSize').value = parseInt(settings.fontSize) || 230;
        document.getElementById('setting-timerLeft').value = settings.timerLeft || 1104;
        document.getElementById('setting-timerTop').value = settings.timerTop || 564;
        
        // Обновляем джойстик
        currentX = parseInt(settings.timerLeft) || 1104;
        currentY = parseInt(settings.timerTop) || 564;
        updateJoystickDisplay();
        
    } catch (error) {
        console.error('Ошибка загрузки настроек:', error);
    }
}

function initJoystick() {
    const joystick = document.getElementById('joystick');
    const handle = joystick.querySelector('.joystick-handle');
    
    // Обработчики для мыши
    joystick.addEventListener('mousedown', startJoystick);
    document.addEventListener('mousemove', moveJoystick);
    document.addEventListener('mouseup', stopJoystick);
    
    // Обработчики для touch-устройств
    joystick.addEventListener('touchstart', startJoystick);
    document.addEventListener('touchmove', moveJoystick);
    document.addEventListener('touchend', stopJoystick);
    
    // Обработчики изменения числовых полей
    document.getElementById('setting-timerLeft').addEventListener('input', updateFromInputs);
    document.getElementById('setting-timerTop').addEventListener('input', updateFromInputs);
}

function startJoystick(e) {
    e.preventDefault();
    joystickActive = true;
    moveJoystick(e);
}

function moveJoystick(e) {
    if (!joystickActive) return;
    
    const joystick = document.getElementById('joystick');
    const handle = joystick.querySelector('.joystick-handle');
    const rect = joystick.getBoundingClientRect();
    
    // Получаем координаты касания/клика
    let clientX, clientY;
    if (e.type.includes('touch')) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
    } else {
        clientX = e.clientX;
        clientY = e.clientY;
    }
    
    // Вычисляем относительные координаты
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = clientX - centerX;
    const deltaY = clientY - centerY;
    
    // Ограничиваем движение внутри джойстика
    const distance = Math.min(Math.sqrt(deltaX * deltaX + deltaY * deltaY), rect.width / 2);
    const angle = Math.atan2(deltaY, deltaX);
    
    const limitedX = Math.cos(angle) * distance;
    const limitedY = Math.sin(angle) * distance;
    
    // Перемещаем ручку джойстика
    handle.style.transform = `translate(${limitedX}px, ${limitedY}px)`;
    
    // Обновляем координаты (масштабируем для большего диапазона)
    const scale = 10; // Чувствительность джойстика
    currentX = Math.max(0, 1104 + Math.round(limitedX * scale));
    currentY = Math.max(0, 564 + Math.round(limitedY * scale));
    
    updateJoystickDisplay();
}

function stopJoystick() {
    joystickActive = false;
    const handle = document.querySelector('.joystick-handle');
    handle.style.transform = 'translate(-50%, -50%)';
}

function updateJoystickDisplay() {
    document.getElementById('joystick-x').textContent = currentX;
    document.getElementById('joystick-y').textContent = currentY;
    document.getElementById('setting-timerLeft').value = currentX;
    document.getElementById('setting-timerTop').value = currentY;
}

function updateFromInputs() {
    currentX = parseInt(document.getElementById('setting-timerLeft').value) || 1104;
    currentY = parseInt(document.getElementById('setting-timerTop').value) || 564;
    updateJoystickDisplay();
}

// Обновите функцию loadAdminData():
async function loadAdminData() {
    await loadStatistics();
    await loadSettings();
    await loadAudioList();
    initJoystick(); // Инициализируем джойстик после загрузки настроек
}

async function uploadBackgroundVideo() {
    const fileInput = document.getElementById('bg-video-upload');
    const file = fileInput.files[0];
    
    if (!file) {
        showMessage('❌ Выберите MP4 файл', 'error');
        return;
    }
    
    if (!file.type.startsWith('video/')) {
        showMessage('❌ Поддерживаются только видеофайлы', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('video', file);
    formData.append('type', 'backgroundVideo'); // Важно: указываем тип
    
    try {
        showMessage('📤 Загружаю фоновое видео...', 'info');
        
        const response = await fetch('/api/upload/video', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage(`✅ Фоновое видео загружено! Оно будет воспроизводиться без звука в цикле.`, 'success');
            fileInput.value = '';
        } else {
            showMessage(`❌ Ошибка загрузки видео: ${result.message}`, 'error');
        }
    } catch (error) {
        console.error('Ошибка загрузки видео:', error);
        showMessage('❌ Ошибка загрузки видео', 'error');
    }
}


async function saveSettings() {
    const settings = {
        switchTime: document.getElementById('setting-switchTime').value,
        fontSize: document.getElementById('setting-fontSize').value + 'pt',
        timerLeft: document.getElementById('setting-timerLeft').value,
        timerTop: document.getElementById('setting-timerTop').value
    };
    
    try {
        const response = await fetch('/api/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(settings)
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage('✅ Настройки сохранены!', 'success');
        } else {
            showMessage('❌ Ошибка сохранения настроек', 'error');
        }
    } catch (error) {
        console.error('Ошибка сохранения настроек:', error);
        showMessage('❌ Ошибка сохранения настроек', 'error');
    }
}
// ==================== АУДИО ====================

async function loadAudioList() {
    try {
        const response = await fetch('/api/media/audio');
        const audioFiles = await response.json();
        
        const audioList = document.getElementById('audio-list');
        audioList.innerHTML = '';
        
        if (audioFiles.length === 0) {
            audioList.innerHTML = '<p>Нет загруженных аудиофайлов</p>';
            return;
        }
        
        audioFiles.forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>🎵 ${file}</span>
                <button onclick="deleteAudio('${file}')" class="delete-btn">🗑️ Удалить</button>
            `;
            audioList.appendChild(fileItem);
        });
        
    } catch (error) {
        console.error('Ошибка загрузки списка аудио:', error);
    }
}

async function uploadAudio() {
    const fileInput = document.getElementById('audio-upload');
    const file = fileInput.files[0];
    
    if (!file) {
        showMessage('❌ Выберите MP3 файл', 'error');
        return;
    }
    
    if (!file.name.toLowerCase().endsWith('.mp3')) {
        showMessage('❌ Поддерживаются только MP3 файлы', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('audio', file);
    
    try {
        showMessage('📤 Загружаю файл...', 'info');
        
        const response = await fetch('/api/upload/audio', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage(`✅ Аудиофайл "${file.name}" загружен! (${(result.size / 1024 / 1024).toFixed(2)} MB)`, 'success');
            fileInput.value = '';
            await loadAudioList();
        } else {
            showMessage(`❌ Ошибка загрузки аудио: ${result.message}`, 'error');
        }
    } catch (error) {
        console.error('Ошибка загрузки аудио:', error);
        showMessage('❌ Ошибка загрузки аудио', 'error');
    }
}

async function deleteAudio(filename) {
    if (!confirm(`Удалить аудиофайл "${filename}"?`)) {
        return;
    }
    
    try {
        const response = await fetch(`/api/media/audio/${filename}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage(`✅ Аудиофайл "${filename}" удален!`, 'success');
            await loadAudioList();
        } else {
            showMessage('❌ Ошибка удаления аудио', 'error');
        }
    } catch (error) {
        console.error('Ошибка удаления аудио:', error);
        showMessage('❌ Ошибка удаления аудио', 'error');
    }
}

// ==================== ИЗОБРАЖЕНИЯ ====================

async function uploadBackground(type) {
    const fileInput = document.getElementById(`bg-${type}-upload`);
    const file = fileInput.files[0];
    
    if (!file) {
        showMessage('❌ Выберите изображение', 'error');
        return;
    }
    
    if (!file.type.startsWith('image/')) {
        showMessage('❌ Поддерживаются только изображения', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('image', file);
    formData.append('type', `background${type.charAt(0).toUpperCase() + type.slice(1)}`);
    
    try {
        showMessage('📤 Загружаю изображение...', 'info');
        
        const response = await fetch('/api/upload/image', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage(`✅ Фоновое изображение загружено!`, 'success');
            fileInput.value = '';
        } else {
            showMessage(`❌ Ошибка загрузки изображения: ${result.message}`, 'error');
        }
    } catch (error) {
        console.error('Ошибка загрузки изображения:', error);
        showMessage('❌ Ошибка загрузки изображения', 'error');
    }
}

// ==================== ВИДЕО ====================

async function uploadVideo() {
    const fileInput = document.getElementById('video-upload');
    const file = fileInput.files[0];
    
    if (!file) {
        showMessage('❌ Выберите MP4 файл', 'error');
        return;
    }
    
    if (!file.type.startsWith('video/')) {
        showMessage('❌ Поддерживаются только видеофайлы', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('video', file);
    formData.append('type', 'congratulationVideo'); // Важно: указываем тип
    
    try {
        showMessage('📤 Загружаю видео-поздравление...', 'info');
        
        const response = await fetch('/api/upload/video', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage(`✅ Видео-поздравление загружено!`, 'success');
            fileInput.value = '';
        } else {
            showMessage(`❌ Ошибка загрузки видео: ${result.message}`, 'error');
        }
    } catch (error) {
        console.error('Ошибка загрузки видео:', error);
        showMessage('❌ Ошибка загрузки видео', 'error');
    }
}

// ==================== ПЕРЕЗАГРУЗКА СЕРВЕРА ====================

async function restartServer() {
    if (!confirm('Перезагрузить сервер? Сайт будет недоступен около 10 секунд.')) {
        return;
    }
    
    try {
        showMessage('🔄 Перезагружаю сервер...', 'info');
        
        const response = await fetch('/api/server/restart', {
            method: 'POST'
        });
        
        const result = await response.json();
        if (result.success) {
            showMessage('✅ Сервер перезагружается... Обновите страницу через 10 секунд', 'success');
            
            let countdown = 10;
            const countdownInterval = setInterval(() => {
                showMessage(`✅ Сервер перезагружается... ${countdown} сек`, 'success');
                countdown--;
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    location.reload();
                }
            }, 1000);
        }
    } catch (error) {
        console.error('Ошибка перезагрузки сервера:', error);
        showMessage('❌ Ошибка перезагрузки сервера', 'error');
    }
}

// ==================== УТИЛИТЫ ====================

function showMessage(text, type) {
    const message = document.createElement('div');
    message.className = type === 'success' ? 'success-message' : 
                        type === 'error' ? 'error-message' : 'info-message';
    message.textContent = text;
    message.style.display = 'block';
    
    if (type === 'info') {
        message.style.background = '#3498db';
    }
    
    document.body.appendChild(message);
    
    setTimeout(() => {
        message.remove();
    }, 5000);
}

// Ввод пароля по нажатию Enter
passwordInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        checkPassword();
    }
});

// Загрузка при открытии страницы
document.addEventListener('DOMContentLoaded', function() {
    passwordInput.focus();
});