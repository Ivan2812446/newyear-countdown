// Элементы DOM
const countdownElement = document.getElementById('countdown');
const backgroundElement = document.getElementById('background');
const backgroundVideoElement = document.getElementById('background-video');
const backgroundMusic = document.getElementById('background-music');
const congratulationVideo = document.getElementById('congratulation-video');
const timerElement = document.querySelector('.timer');

// Переменные для управления плейлистом
let currentPlaylist = [];
let remainingTracks = [];
let isPlaying = false;

// Настройки по умолчанию
let settings = {
    switchTime: '23:55',
    fontSize: '230pt',
    timerLeft: '1104',
    timerTop: '564',
    backgroundVideo: 'background-video.mp4'
};

// Загрузка настроек с сервера
async function loadSettings() {
    try {
        const response = await fetch('/api/settings');
        const serverSettings = await response.json();
        Object.assign(settings, serverSettings);
        applySettings();
    } catch (error) {
        console.error('Ошибка загрузки настроек:', error);
        applySettings(); // Применяем настройки по умолчанию
    }
}

// Применение настроек
function applySettings() {
    if (countdownElement) {
        countdownElement.style.fontSize = settings.fontSize;
        console.log(`✅ Установлен размер шрифта: ${settings.fontSize}`);
    }
    
    if (timerElement) {
        timerElement.style.left = settings.timerLeft + 'px';
        timerElement.style.top = settings.timerTop + 'px';
        console.log(`✅ Установлена позиция таймера: ${settings.timerLeft}px, ${settings.timerTop}px`);
    }
    
    // Управление фоном - ТАЙМЕР ВСЕГДА ВИДЕН ПОВЕРХ ФОНА
    if (backgroundVideoElement && settings.backgroundVideo) {
        backgroundVideoElement.src = `media/video/${settings.backgroundVideo}`;
        
        // Пытаемся воспроизвести видео фон
        backgroundVideoElement.play().then(() => {
            console.log('✅ Фоновое видео запущено');
            backgroundVideoElement.classList.remove('hidden');
            backgroundElement.classList.add('hidden');
            
            // Таймер всегда виден поверх фона
            timerElement.style.display = 'block';
        }).catch(error => {
            console.log('❌ Не удалось запустить фоновое видео, используем изображение:', error);
            backgroundVideoElement.classList.add('hidden');
            backgroundElement.classList.remove('hidden');
            backgroundElement.style.backgroundImage = `url('media/images/background.jpg')`;
            
            // Таймер всегда виден поверх фона
            timerElement.style.display = 'block';
        });
    } else {
        // Используем изображение если видео нет
        backgroundVideoElement.classList.add('hidden');
        backgroundElement.classList.remove('hidden');
        backgroundElement.style.backgroundImage = `url('media/images/background.jpg')`;
        
        // Таймер всегда виден поверх фона
        timerElement.style.display = 'block';
    }
}

function updateCountdown() {
    if (!countdownElement) return;

    const now = new Date();
    const currentYear = now.getFullYear();
    const newYear = new Date(currentYear + 1, 0, 1, 0, 0, 0, 0);
    
    const diff = newYear - now;
    
    if (diff <= 0) {
        countdownElement.textContent = '00:00:00:00';
        return;
    }
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);
    
    countdownElement.textContent = 
        `${days.toString().padStart(2, '0')}:${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    // Проверка времени для показа поздравления
    const [switchHour, switchMinute] = settings.switchTime.split(':').map(Number);
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    // Проверяем, наступило ли время переключения
    if (currentHour === switchHour && currentMinute === switchMinute) {
        console.log(`⏰ Время переключения! ${settings.switchTime}`);
        showCongratulation();
    }
}

// Обновите функцию showCongratulation() для управления фоном при поздравлении:
function showCongratulation() {
    console.log('🎬 Показываю видео-поздравление');
    
    // Скрываем таймер при показе поздравления
    if (timerElement) {
        timerElement.style.display = 'none';
    }
    
    if (backgroundMusic) {
        backgroundMusic.pause();
        isPlaying = false;
    }
    
    // Останавливаем фоновое видео
    if (backgroundVideoElement) {
        backgroundVideoElement.pause();
    }
    
    if (congratulationVideo) {
        congratulationVideo.classList.remove('hidden');
        congratulationVideo.play();
        
        congratulationVideo.onended = function() {
            console.log('✅ Видео-поздравление закончилось');
            
            // После поздравления возвращаем фон и показываем таймер
            if (backgroundElement) {
                backgroundElement.style.backgroundImage = `url('media/images/after-congratulation-bg.jpg')`;
            }
            
            // Показываем таймер снова
            if (timerElement) {
                timerElement.style.display = 'block';
            }
            
            // Запускаем фоновое видео если оно было
            if (backgroundVideoElement && settings.backgroundVideo) {
                backgroundVideoElement.play().catch(e => {
                    console.log('Не удалось перезапустить фоновое видео');
                });
            }
            
            if (backgroundMusic) {
                playNextTrack();
            }
            
            // Скрываем видео-поздравление
            congratulationVideo.classList.add('hidden');
        };
    }
}

// Получение случайного плейлиста
async function getRandomPlaylist() {
    try {
        const response = await fetch('/api/playlist/random');
        const playlist = await response.json();
        return playlist;
    } catch (error) {
        console.error('Ошибка загрузки плейлиста:', error);
        return [];
    }
}

// Перемешивание массива (алгоритм Фишера-Йейтса)
function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// Воспроизведение следующего трека
function playNextTrack() {
    if (!backgroundMusic) return;
    
    // Если треки закончились, перемешиваем заново
    if (remainingTracks.length === 0) {
        if (currentPlaylist.length === 0) {
            console.log('❌ В плейлисте нет треков');
            return;
        }
        remainingTracks = shuffleArray([...currentPlaylist]);
        console.log('🔄 Плейлист перемешан заново');
    }
    
    // Берем следующий трек
    const nextTrack = remainingTracks.shift();
    backgroundMusic.src = `media/audio/${nextTrack}`;
    
    console.log(`🎵 Воспроизводится: ${nextTrack}`);
    console.log(`📊 Осталось треков: ${remainingTracks.length}`);
    
    // Воспроизводим
    backgroundMusic.play().catch(e => {
        console.log('Автовоспроизведение заблокировано');
    });
    
    isPlaying = true;
}

// Инициализация плейлиста
async function initPlaylist() {
    if (!backgroundMusic) return;
    
    currentPlaylist = await getRandomPlaylist();
    
    if (currentPlaylist.length === 0) {
        console.log('❌ В плейлисте нет треков');
        return;
    }
    
    console.log(`🎵 Загружен плейлист из ${currentPlaylist.length} треков`);
    
    // Инициализируем оставшиеся треки
    remainingTracks = shuffleArray([...currentPlaylist]);
    
    // Начинаем воспроизведение
    playNextTrack();
    
    // Обработчик окончания трека - ВАЖНО: добавляем ОДИН раз
    backgroundMusic.addEventListener('ended', function() {
        console.log('🎵 Трек закончился, переключаю...');
        playNextTrack();
    });
    
    // Обработчик ошибок воспроизведения
    backgroundMusic.addEventListener('error', function(e) {
        console.error('❌ Ошибка воспроизведения трека:', e);
        setTimeout(playNextTrack, 1000);
    });
}

// Вход в полноэкранный режим
function enterFullscreen() {
    const element = document.documentElement;
    
    if (element.requestFullscreen) {
        element.requestFullscreen().catch(e => {
            console.log('Полноэкранный режим не поддерживается или заблокирован');
            showFullscreenButton();
        });
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen().catch(e => {
            console.log('Полноэкранный режим заблокирован');
            showFullscreenButton();
        });
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen().catch(e => {
            console.log('Полноэкранный режим заблокирован');
            showFullscreenButton();
        });
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen().catch(e => {
            console.log('Полноэкранный режим заблокирован');
            showFullscreenButton();
        });
    } else {
        showFullscreenButton();
    }
}

// Показать кнопку для ручного включения полноэкранного режима
function showFullscreenButton() {
    // Создаем кнопку если её нет
    if (!document.getElementById('fullscreen-btn')) {
        const button = document.createElement('button');
        button.id = 'fullscreen-btn';
        button.innerHTML = '🖥️ ВКЛЮЧИТЬ ПОЛНЫЙ ЭКРАН';
        button.style.position = 'fixed';
        button.style.top = '20px';
        button.style.left = '50%';
        button.style.transform = 'translateX(-50%)';
        button.style.zIndex = '10000';
        button.style.padding = '15px 30px';
        button.style.background = 'rgba(255,255,255,0.9)';
        button.style.color = '#000';
        button.style.border = 'none';
        button.style.borderRadius = '25px';
        button.style.fontSize = '18px';
        button.style.fontWeight = 'bold';
        button.style.cursor = 'pointer';
        button.style.boxShadow = '0 4px 15px rgba(0,0,0,0.3)';
        
        button.addEventListener('click', function() {
            enterFullscreen();
            button.remove();
        });
        
        document.body.appendChild(button);
        
        // Автоматически скрыть через 10 секунд
        setTimeout(() => {
            if (button.parentNode) {
                button.remove();
            }
        }, 10000);
    }
}

// Блокировка ориентации
function lockOrientation() {
    if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('landscape').catch(function(error) {
            console.log('Ориентация не может быть заблокирована');
        });
    }
}

// Выход из полноэкранного режима по двойному клику
document.addEventListener('dblclick', function() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    }
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    console.log('Таймер загружен');
    
    if (!countdownElement) {
        console.error('Элемент countdown не найден');
    }
    
    applySettings();
    
    // Пытаемся войти в полноэкранный режим автоматически
    // (работает только если страница была открыта по действию пользователя)
    setTimeout(() => {
        enterFullscreen();
    }, 500);
    
    lockOrientation();
    initPlaylist();
    updateCountdown();
    setInterval(updateCountdown, 1000);
    
    if (typeof countdownAPI !== 'undefined') {
        countdownAPI.trackPageView('timer', countdownAPI.getUserId());
    }
});

// Обновляем инициализацию:
document.addEventListener('DOMContentLoaded', function() {
    console.log('Таймер загружен');
    
    // Сначала загружаем настройки, потом применяем
    loadSettings().then(() => {
        if (!countdownElement) {
            console.error('Элемент countdown не найден');
        }
        
        enterFullscreen();
        lockOrientation();
        initPlaylist();
        updateCountdown();
        setInterval(updateCountdown, 1000);
        
        if (typeof countdownAPI !== 'undefined') {
            countdownAPI.trackPageView('timer', countdownAPI.getUserId());
        }
    });
});