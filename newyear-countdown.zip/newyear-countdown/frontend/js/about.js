// Загрузка контента страницы "Об авторе"
async function loadAboutContent() {
    try {
        const content = await countdownAPI.getAboutContent();
        if (content) {
            document.getElementById('about-text').innerHTML = content;
        }
    } catch (error) {
        console.error('Ошибка загрузки контента:', error);
    }
}

function goBack() {
    window.location.href = 'index.html';
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', async function() {
    await loadAboutContent();
    countdownAPI.trackPageView('about', countdownAPI.getUserId());
});