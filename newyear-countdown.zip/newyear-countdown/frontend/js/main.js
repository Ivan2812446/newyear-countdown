// Элементы DOM
const splashScreen = document.getElementById('splash-screen');
const mainMenu = document.getElementById('main-menu');
const activateAudioBtn = document.getElementById('activate-audio');
const backgroundMusic = document.getElementById('background-music');

// Переменные для управления плейлистом
let currentPlaylist = [];
let remainingTracks = [];
let isPlaying = false;

// Получение случайного плейлиста
async function getRandomPlaylist() {
    try {
        const response = await fetch('/api/playlist/random');
        const playlist = await response.json();
        return playlist;
    } catch (error) {
        console.error('Ошибка загрузки плейлиста:', error);
        return [];
    }
}

// Перемешивание массива
function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// Воспроизведение следующего трека
function playNextTrack() {
    if (!backgroundMusic) return;
    
    // Если треки закончились, перемешиваем заново
    if (remainingTracks.length === 0) {
        if (currentPlaylist.length === 0) {
            console.log('❌ В плейлисте нет треков');
            return;
        }
        remainingTracks = shuffleArray([...currentPlaylist]);
        console.log('🔄 Плейлист перемешан заново');
    }
    
    // Берем следующий трек
    const nextTrack = remainingTracks.shift();
    backgroundMusic.src = `media/audio/${nextTrack}`;
    
    console.log(`🎵 Воспроизводится: ${nextTrack}`);
    console.log(`📊 Осталось треков: ${remainingTracks.length}`);
    
    // Воспроизводим
    backgroundMusic.play().catch(e => {
        console.log('Автовоспроизведение заблокировано');
    });
    
    isPlaying = true;
}

// Инициализация музыки
async function initMusic() {
    try {
        currentPlaylist = await getRandomPlaylist();
        
        if (currentPlaylist.length === 0) {
            console.log('❌ В плейлисте нет треков');
            // Используем fallback
            backgroundMusic.src = 'media/audio/track1.mp3';
            backgroundMusic.play().catch(e => {
                console.log('Автовоспроизведение заблокировано');
            });
        } else {
            // Инициализируем оставшиеся треки
            remainingTracks = shuffleArray([...currentPlaylist]);
            
            // Начинаем воспроизведение
            playNextTrack();
            
            // Обработчик окончания трека - ВАЖНО: добавляем ОДИН раз
            backgroundMusic.addEventListener('ended', function() {
                console.log('🎵 Трек закончился, переключаю...');
                playNextTrack();
            });
            
            // Обработчик ошибок воспроизведения
            backgroundMusic.addEventListener('error', function(e) {
                console.error('❌ Ошибка воспроизведения трека:', e);
                setTimeout(playNextTrack, 1000);
            });
        }
        
    } catch (error) {
        console.error('Ошибка инициализации музыки:', error);
    }
}

// Функция для открытия таймера в полноэкранном режиме
function openTimer() {
    // Открываем страницу таймера
    const timerWindow = window.open('timer.html', '_blank');
    
    if (timerWindow) {
        // Даем окну время на загрузку
        setTimeout(() => {
            // Пытаемся активировать полноэкранный режим
            try {
                timerWindow.focus();
                // Некоторые браузеры могут блокировать это, но попробуем
                console.log('🖥️ Открываю таймер в новом окне');
            } catch (error) {
                console.error('Ошибка при открытии таймера:', error);
            }
        }, 1000);
    } else {
        // Если всплывающие окна заблокированы, открываем в этой же вкладке
        window.location.href = 'timer.html';
        alert('Разрешите всплывающие окна для автоматического полноэкранного режима!');
    }
}

// Альтернативная функция для открытия таймера с кнопкой полноэкранного режима
function openTimerWithFullscreen() {
    // Сохраняем информацию о том, что нужно включить полноэкранный режим
    localStorage.setItem('autoFullscreen', 'true');
    window.location.href = 'timer.html';
}

// Активация звука и показ главного меню
activateAudioBtn.addEventListener('click', function() {
    initMusic();
    
    splashScreen.classList.add('hidden');
    mainMenu.classList.remove('hidden');
});

// Обновляем кнопку открытия таймера в HTML
function updateTimerButton() {
    // Найдем кнопку и обновим её обработчик
    const timerButtons = document.querySelectorAll('button[onclick*="openTimer"]');
    timerButtons.forEach(button => {
        button.onclick = openTimerWithFullscreen;
    });
}

// Функции навигации
function openGitHub() {
    window.open('https://github.com/Ivan2812446/newyear-countdown', '_blank');
}

function openAbout() {
    window.location.href = 'about.html';
}

// Статистика посещения
function trackPageView(page) {
    fetch('/api/statistics/pageview', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ page: page })
    });
}

// Отслеживание при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    trackPageView('main');
    updateTimerButton();
});